from PIL import Image
import numpy as np
import cv2
import glob

for file in glob.glob("*_depth.png"):
    im = Image.open(file, 'r')
    pixel_val = list(im.getdata())
    for i in range(len(pixel_val)):
        if (pixel_val[i]==32001):
            pixel_val[i]=0
    np_arr = np.array(pixel_val)
    #print(np_arr.shape)
    #print(np_arr.size)
    #print(np_arr.ndim)
    np_reshaped = np_arr.reshape(240, 320)
    modified_depth_file = file[:-4] + '_modified.png'
    cv2.imwrite(modified_depth_file, (np_reshaped).astype(np.uint16))


'''im = Image.open("000000_depth_modified.png", 'r')

pixel_val = list(im.getdata())
print(pixel_val)'''
