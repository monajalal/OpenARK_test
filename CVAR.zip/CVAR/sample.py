"""This is a demo script for loading the dataset

Created on 18.04.2016

@author: Markus Oberweger <oberweger@icg.tugraz.at>
"""

import os
import numpy as np
import scipy.io
import matplotlib
import matplotlib.pyplot as plt

objdir = './'
subdirs = sorted([name for name in os.listdir(objdir) if os.path.isdir(os.path.join(objdir, name))])

# iterate all subdirectories
for subdir in subdirs:
    trainlabels = '{}/{}/joint.txt'.format(objdir, subdir)

    inputfile = open(trainlabels)
    # read number of samples
    nImgs = int(inputfile.readline())

    for i in xrange(min(10, nImgs)):
        line = inputfile.readline()
        part = line.split(' ')
        part.pop(0)  # remove filename

        dptFileName = '{}/{}/{}_depth.png'.format(objdir, subdir, str(i).zfill(6))

        if not os.path.isfile(dptFileName):
            print("File {} does not exist!".format(dptFileName))
            continue
        dpt = scipy.misc.imread(dptFileName).astype('float32')
        # joints in image coordinates
        gtorig = np.zeros((21, 3), np.float32)
        for joint in xrange(gtorig.shape[0]):
            for xyz in xrange(0, 3):
                gtorig[joint, xyz] = part[joint * 3 + xyz]

        fig = plt.figure()
        ax = fig.add_subplot(111)
        ax.imshow(dpt, cmap=matplotlib.cm.jet, interpolation='nearest')
        ax.scatter(gtorig[:, 0], gtorig[:, 1])
        ax.plot(gtorig[0:5, 0], gtorig[0:5, 1], c='r')
        ax.plot(np.hstack((gtorig[0, 0], gtorig[5:9, 0])),
                np.hstack((gtorig[0, 1], gtorig[5:9, 1])), c='r')
        ax.plot(np.hstack((gtorig[0, 0], gtorig[9:13, 0])),
                np.hstack((gtorig[0, 1], gtorig[9:13, 1])), c='r')
        ax.plot(np.hstack((gtorig[0, 0], gtorig[13:17, 0])),
                np.hstack((gtorig[0, 1], gtorig[13:17, 1])), c='r')
        ax.plot(np.hstack((gtorig[0, 0], gtorig[17:21, 0])),
                np.hstack((gtorig[0, 1], gtorig[17:21, 1])), c='r')
        for j in xrange(gtorig.shape[0]):
            ax.annotate(str(j), (int(gtorig[j, 0]), int(gtorig[j, 1])))
        plt.show()
