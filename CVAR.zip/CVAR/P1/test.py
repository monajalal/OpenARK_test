import numpy as np
from matplotlib import pyplot as plt
import matplotlib
import glob
import cv2
import scipy
from scipy import misc
from PIL import Image


'''for file in glob.glob("*_depth.png"):
    im = Image.open(file, 'r')
    im_list =list(im.getdata())
    for i in range(len(im_list)):
        if im_list[i] == 32001:
            im_list[i] = 0
    np_arr = np.array(im_list)
    np_reshaped = np_arr.reshape(240, 321)


    #r = np.ptp(im,axis=1)

    depth_image_filename = file[:-4]+'_modified'+'.png'

    cv2.imwrite(depth_image_filename, (np_reshaped).astype(np.uint16))


'''

im = Image.open("000000_depth_modified.png", 'r')
pixel_val = list(im.getdata())
print(pixel_val)

