import itertools

fingertips_file = open("fingertips.txt", 'w')
with open("joint.txt") as joints_file:
    next(joints_file)
    for line in joints_file:
        line_split = ' '.join(line.split(' ')[1:]).rstrip()
        line_split = line_split.split(' ')
        list_of_list = []
        iterable = iter(line_split)
        sliced_list = list(iter(lambda: list(itertools.islice(iterable, 3)), []))
        fingertips = []
        #fingertips.extend([sliced_list[16], sliced_list[12], sliced_list[8], sliced_list[4], sliced_list[20]])
        fingertips.append(sliced_list[16])
        fingertips.append(sliced_list[12])
        fingertips.append(sliced_list[8])
        fingertips.append(sliced_list[4])
        fingertips.append(sliced_list[20])
        #fingertips.extend([sliced_list[20], sliced_list[4], sliced_list[8], sliced_list[12], sliced_list[16]])
        flat_list = [item for sublist in fingertips for item in sublist]
        str_flat_list = " ".join(str(x) for x in flat_list)
        fingertips_file.write(str_flat_list+"\n")