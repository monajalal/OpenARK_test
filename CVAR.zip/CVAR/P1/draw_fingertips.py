import cv2

fingertips_file = open("fingertips.txt")
#for line in fingertips_file:
#    print(line)


#fingertips = [135.796, 130.865, 589.287, 163.711, 95.555, 607.424, 180.094, 88.832, 611.303, 193.687, 94.635, 621.528, 210.707, 112.927, 618.811]
test_image = cv2.imread("000000_depth.png")
'''cv2.circle(test_image, (int(135.796), int(130.865)), 1, (0,255,0), -1)
cv2.circle(test_image, (int(163.711), int(95.555)), 1, (0,255,0), -1)
cv2.circle(test_image, (int(180.094), int(88.832)), 1, (0,255,0), -1)
cv2.circle(test_image, (int(193.687), int(94.635)), 1, (0,255,0), -1)
cv2.circle(test_image, (int(210.707), int(112.927)), 1, (0,255,0), -1)
'''

'''fingertips = [210.707, 112.927, 618.811, 193.687, 94.635, 621.528, 180.094, 88.832, 611.303, 163.711, 95.555, 607.424, 135.796, 130.865, 589.287]

cv2.circle(test_image, (int(210.707), int(112.927)), 1, (0, 255, 0, -1))
cv2.circle(test_image, (int(193.687), int(94.635)), 1, (0, 255, 0, -1))
cv2.circle(test_image, (int(180.094), int(88.832)), 1, (0, 255, 0, -1))
cv2.circle(test_image, (int(163.711), int(95.555)), 1, (0, 255, 0, -1))
cv2.circle(test_image, (int(135.796), int(130.865)), 1, (0, 255, 0, -1))'''


'''fingertips_165 = [208.330, 96.330, 555.066, 183.592, 80.750, 550.668, 162.113, 81.536, 563.814, 155.679, 123.831, 581.846, 127.358, 120.303, 515.697]
test_image = cv2.imread('000165_depth.png')
cv2.circle(test_image, (int(208.330), int(96.330)), 1, (0,255,0), -1)
cv2.circle(test_image, (int(183.592), int(80.750)), 1, (0,255,0), -1)
cv2.circle(test_image, (int(162.113), int(81.536)), 1, (0,255,0), -1)
cv2.circle(test_image, (int(155.679), int(123.831)), 1, (0,255,0), -1)
cv2.circle(test_image, (int(127.358), int(120.303)), 1, (0,255,0), -1)
'''

'''test_image = cv2.imread("000214_depth.png")
fingertips = [164.938, 159.389, 591.818, 156.789, 150.321, 604.828, 158.764, 139.147, 601.994, 159.257, 126.764, 579.404, 162.434, 88.314, 533.592]
cv2.circle(test_image, (int(164.938), int(159.389)), 1, (0,255,0), -1)
cv2.circle(test_image, (int(156.789), int(150.321)), 1, (0,255,0), -1)
cv2.circle(test_image, (int(158.764), int(139.147)), 1, (0,255,0), -1)
cv2.circle(test_image, (int(159.257), int(126.764)), 1, (0,255,0), -1)
cv2.circle(test_image, (int(162.434), int(88.314)), 1, (0,255,0), -1)'''

test_image = cv2.imread("000048_depth.png")
fingertips = [183.815, 117.319, 632.790, 186.256, 105.004, 631.818, 184.479, 98.312, 639.874, 177.144, 99.378, 609.611, 162.864, 111.723, 540.189]
cv2.circle(test_image, (int(183.815), int(117.319)), 1, (0,255,0), -1)
cv2.circle(test_image, (int(186.256), int(105.004)), 1, (0,255,0), -1)
cv2.circle(test_image, (int(184.479), int(98.312)), 1, (0,255,0), -1)
cv2.circle(test_image, (int(177.144), int(99.378)), 1, (0,255,0), -1)
cv2.circle(test_image, (int(162.864), int(111.723)), 1, (0,255,0), -1)






cv2.namedWindow('dst')
cv2.imshow('dst', test_image)


image_resized = cv2.resize(test_image, (640, 480), interpolation=cv2.INTER_AREA)
cv2.imshow("resized", image_resized)
cv2.waitKey(0)

cv2.destroyAllWindows()